use apollo;

insert into `user`(id, shop_name, enabled, expire_time, created, last_modified)
values (1,'shop',1,'2100-10-10 01:01:01',now(),now());
