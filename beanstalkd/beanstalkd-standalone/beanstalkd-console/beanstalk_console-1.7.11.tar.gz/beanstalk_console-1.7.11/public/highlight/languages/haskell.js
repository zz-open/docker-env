/*
Language: Haskell
Author: Jeremy Hull <sourdrums@gmail.com>
*/

function(hljs) {
  var TYPE = {
    className: 'type',
    begin: '\\b[A-Z][\\w\']*',
    relevance: 0
  };
  var CONTAINER = {
    className: 'container',
    begin: '\\(', end: '\\)',
    contains: [
      {className: 'type', begin: '\\b[A-Z][\\w]*(\\((\\.\\.|,|\\w+)\\))?'},
      {className: 'title', begin: '[_a-z][\\w\']*'}
    ]
  };
  var CONTAINER2 = {
    className: 'container',
    begin: '{', end: '}',
    contains: CONTAINER.contains
  }

  return {
    defaultMode: {
      keywords:
        'let in if then else case of where do module import hiding qualified type data ' +
        'newtype deriving class instance not as foreign ccall safe unsafe',
      contains: [
        {
          className: 'comment',
          begin: '--', end: '$'
        },
        {
          className: 'preprocessor',
          begin: '{-#', end: '#-}'
        },
        {
          className: 'comment',
          contains: ['self'],
          begin: '{-', end: '-}'
        },
        {
          className: 'string',
          begin: '\\s+\'', end: '\'',
          contains: [hljs.BACKSLASH_ESCAPE],
          relevance: 0
        },
        hljs.QUOTE_STRING_MODE,
        {
          className: 'import',
          begin: '\\bimport', end: '$',
          keywords: 'import qualified as hiding',
          contains: [CONTAINER],
          illegal: '\\W\\.|;'
        },
        {
          className: 'module',
          begin: '\\bmodule', end: 'where',
          keywords: 'module where',
          contains: [CONTAINER],
          illegal: '\\W\\.|;'
        },
        {
          className: 'class',
          begin: '\\b(class|instance)', end: 'where',
          keywords: 'class where instance',
          contains: [TYPE]
        },
        {
          className: 'typedef',
          begin: '\\b(data|(new)?type)', end: '$',
          keywords: 'data type newtype deriving',
          contains: [TYPE, CONTAINER, CONTAINER2]
        },
        hljs.C_NUMBER_MODE,
        {
          className: 'shebang',
          begin: '#!\\/usr\\/bin\\/env\ runhaskell', end: '$'
        },
        TYPE,
        {
          className: 'title', begin: '^[_a-z][\\w\']*'
        }
      ]
    }
  };
}
